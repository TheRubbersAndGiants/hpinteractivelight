color 20
winget install --id "9ph760wdkx0t" -s msstore